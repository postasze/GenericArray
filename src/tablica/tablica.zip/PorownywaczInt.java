package tablica;

public class PorownywaczInt implements Porownywacz<Integer> {
	public boolean porownaj (Integer a, Integer b){ 
		return a < b; 
		}
}
