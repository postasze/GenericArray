package tablica;

public interface Porownywacz<T> {
	public boolean porownaj (T a, T b);
}
